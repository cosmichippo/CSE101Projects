cd RoboGrader
python3 robochecker.py NQueens ~/workspace
cd ..
